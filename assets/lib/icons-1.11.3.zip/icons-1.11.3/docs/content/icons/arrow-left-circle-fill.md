---
title: Arrow left circle fill
categories:
  - Shape Arrows
tags:
  - arrow
  - circle
---
