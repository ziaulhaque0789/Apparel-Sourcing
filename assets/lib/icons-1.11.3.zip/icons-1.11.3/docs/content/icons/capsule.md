---
title: Capsule
categories:
  - Medical
tags:
  - rx
  - pills
  - capsules
  - medicine
---
