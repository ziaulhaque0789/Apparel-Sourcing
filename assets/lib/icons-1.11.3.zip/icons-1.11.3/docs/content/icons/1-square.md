---
title: 1 square
categories:
  - Shapes
tags:
  - number
  - numeral
---
